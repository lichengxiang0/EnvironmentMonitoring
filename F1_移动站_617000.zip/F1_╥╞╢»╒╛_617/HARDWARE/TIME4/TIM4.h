#ifndef _TIMER_H_
#define _TIMER_H_
#include "stm32f10x.h"
#include "stdio.h"

void Tim4_Init(u16 period_num);










#endif
