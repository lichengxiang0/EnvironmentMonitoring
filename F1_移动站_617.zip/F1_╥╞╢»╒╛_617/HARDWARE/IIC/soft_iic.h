#ifndef	_SOFT_IIC_H
#define _SOFT_IIC_H
//#include "stm32f1xx_hal.h"
#include "stm32f10x.h"
//typedef enum {I2C_READY = 0,I2C_BUS_BUSY,I2C_BUS_ERROR,I2C_NACK,I2C_ACK} I2C_Status;

#define		ICM20602_DEVICE_ADDRESS										(0xD0)  //0xD0@SA0=0  0xD2@SA0=1 

#define		ICM20602_ID_REG_ADDRESS										(0x75)  //who am i

/*ICM20602���üĴ���*/
#define 	ICM20602_CFG_REG_ADDR											(0x1A)
#define 	ICM20602_GYRO_CFG_REG_ADDR								(0x1B)
#define 	ICM20602_ACC_CFG_REG_ADDR									(0x1C)
#define 	ICM20602_ACC_CFG2_REG_ADDR								(0x1D)
#define 	ICM20602_GYRO_LPM_CFG_REG_ADDR						(0x1E)


/*ICM20602�����ݼĴ���*/
#define 	ICM20602_ACC_XOUT_H_REG_ADDR							(0x3B)
#define 	ICM20602_ACC_XOUT_L_REG_ADDR							(0x3C)
#define 	ICM20602_ACC_YOUT_H_REG_ADDR							(0x3D)
#define 	ICM20602_ACC_YOUT_L_REG_ADDR							(0x3E)
#define 	ICM20602_ACC_ZOUT_H_REG_ADDR							(0x3F)
#define 	ICM20602_ACC_ZOUT_L_REG_ADDR							(0x40)

#define 	ICM20602_TMEP_OUT_H_REG_ADDR							(0x41)
#define 	ICM20602_TMEP_OUT_L_REG_ADDR							(0x42)

#define 	ICM20602_GYRO_XOUT_H_REG_ADDR							(0x43)
#define 	ICM20602_GYRO_XOUT_L_REG_ADDR							(0x44)
#define 	ICM20602_GYRO_YOUT_H_REG_ADDR							(0x45)
#define 	ICM20602_GYRO_YOUT_L_REG_ADDR							(0x46)
#define 	ICM20602_GYRO_ZOUT_H_REG_ADDR							(0x47)
#define 	ICM20602_GYRO_ZOUT_L_REG_ADDR							(0x48)

/*ICM20602�ĵ�Դ�Ĵ���*/
#define 	ICM20602_USER_CTRL_REG_ADDR								(0x6A)
#define 	ICM20602_PWR_MGMT_1_REG_ADDR							(0x6B)
#define 	ICM20602_PWR_MGMT_2_REG_ADDR							(0x6C)


static		float	f_icm20602_gyro_scale = 1/16.4f;    	//default 2000dps
static		float	f_icm20602_acc_scale = 1/16384.f;		//default ��2g

void I2C_Configuration(void);
void I2C_Write_Single_Reg(uint8_t device_addr,uint8_t reg_addr,uint8_t reg_value);
void I2C_Write_Multi_Reg(uint8_t device_addr,uint8_t reg_addr,uint8_t *value_buf_addr, uint8_t reg_number);
uint8_t I2C_Read_Single_Reg(uint8_t device_addr,uint8_t reg_addr);
void I2C_Read_Multi_Reg(uint8_t device_addr,uint8_t reg_addr, uint8_t *value_buf_addr, uint8_t reg_number); 
void	Gyro_Data_Fliter(float* p_f_gyro_in_p,	float* p_f_gyro_out_p,	FlagStatus	*en_first_run_flag_p);
void	Cal_Filter_Sensor_Data(void);
void	Read_Icm20602_Data_Soft(float *	p_f_icm20602_gyro_data_p,	float *p_f_icm20602_acc_data_p);
void	Acc_Data_Fliter(float* p_f_acc_in_p,	float* p_f_acc_out_p,	FlagStatus *en_first_run_flag_p);
void	Init_Icm20602_Soft(void);
void	Task_Get_Imu_Sensor_Data(void);
#endif
