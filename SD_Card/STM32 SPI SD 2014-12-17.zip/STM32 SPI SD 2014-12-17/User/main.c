

#include "stm32f10x.h"
#include "bsp_sysTick.h"
#include "bsp_usart1.h"
#include "spi.h"
#include "sd.h"

#include <math.h>
#include <stdlib.h>
												 		    									    		    	 		  
uint8_t buf[512];//SD�����ݻ�����
uint8_t buf23[512];//SD�����ݻ�����
int main(void)
{	
	uint32_t sd_size,i=0;
	uint8_t t=0;					    
	USART1_Config();	  
	for(i=0;i<512;i++)
	  buf23[i]=i;	//��ֵ	 
	while(SD_Init()!=0)//��ⲻ��SD��
	{
		printf("SD Card Failed!\r\n");
		Delay_Ms(500);
		printf("Please Check!      \r\n");
		Delay_Ms(500);
	}
	//���SD���ɹ� 											    
	printf("SD Card Checked OK \r\n");
	printf("SD Card Size:    Mb\r\n");
	sd_size=SD_GetCapacity();
	printf("%d\r\n",sd_size>>20);//��ʾSD������
	SD_WriteSingleBlock(5,buf23);	 //д
	while(1)
	{
		if(t==30)//ÿ6s��ִ��һ��
		{
			if(SD_ReadSingleBlock(5,buf)==0)//��
			{	
				printf("USART1 Sending Data...\r\n");
				printf("SECTOR 0 DATA:\r\n");
				for(sd_size=0;sd_size<512;sd_size++)//��ӡ
				{
					printf("%x \r\n",buf[sd_size]);	
				}
				printf("\nDATA ENDED\n");
				printf("USART1 Send Data Over!\r\n");
			}
			t=0;
		}   
		t++;
		Delay_Ms(5000);
	}
}
