#ifndef __USART1_H
#define	__USART1_H

#include "stm32f10x.h"
#include <stdio.h>

void USART1_Config(void);
int fputc(int ch, FILE *f);
int fgetc(FILE *f);
void USART1_printf(USART_TypeDef* USARTx, uint8_t *Data,...);
void USART_Clear_Buf(u8 *a,u16 b);
void USART_Send_Byte(USART_TypeDef* USARTx,u8 byte);
void USART_Send_Str(USART_TypeDef* USARTx,u8 *s);
void USART_Send_Str_0_Num(USART_TypeDef* USARTx,u8 *s,u16 num);


#endif /* __USART1_H */
