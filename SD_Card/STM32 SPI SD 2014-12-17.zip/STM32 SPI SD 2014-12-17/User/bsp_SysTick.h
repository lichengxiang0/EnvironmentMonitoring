#ifndef __SYSTICK_H
#define __SYSTICK_H

#include "stm32f10x.h"

void SysTick_Init(uint32_t a);
void Delay_Us(__IO u32 nTime);
void Delay_Ms(__IO u32 nTime);
void TimingDelay_Decrement(void);
#endif /* __SYSTICK_H */
