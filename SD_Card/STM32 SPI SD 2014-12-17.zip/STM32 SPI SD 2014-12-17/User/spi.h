#ifndef __SPI_FLASH_H
#define __SPI_FLASH_H

#include "stm32f10x.h"

#define SPI_CS_LOW()       GPIO_ResetBits(GPIOA, GPIO_Pin_4)
#define SPI_CS_HIGH()      GPIO_SetBits(GPIOA, GPIO_Pin_4)

void SPIx_Init(uint16_t speed);
uint8_t SPIx_ReadWriteByte(uint8_t TxData);

#endif /* __SPI_FLASH_H */

