#ifndef    __STM32_CRC_H__
#define    __STM32_CRC_H__

#include "stm32f10x.h"


void STM32_CRC_Init(void) ;

u32 ST32_CRC_DATA_Str(u32 *BUFF ,u16  len) ;


#endif
